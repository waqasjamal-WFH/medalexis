/*global angular */
(function () {
    'use strict';
    angular.module('AngularPdfMakeExample', ['angular.pdf.make', 'AngularPdfMakeExample.controller']);
}());
